import java.util.Scanner;
 
class Example1{
Scanner s=new Scanner(System.in);
  public void Valid() {


  
public static main(String agrs[]){
  
}
  


  
  