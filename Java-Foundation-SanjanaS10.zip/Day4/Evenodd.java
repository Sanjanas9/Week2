import.java.util.Scanner;
class Evenodd
  {
    Scanner s= new Scanner(System.in);
    public void isEven()
    {
      System.out.println("enter the number to check it is even or odd");
      int a = s.nextInt();
      if(a%2==0)
      {
         System.out.println("the even number is" +a);
      }
      else
      {
         System.out.println("the odd number is" +a);
      }
        
      public void isprime
        {
         System.out.println("enter the number to check it is prime or not");
        int num=0;
        num=s.nextInt();
        int count=0;
        for(int i=1;i=num%2;i++)
        
        }
    }
    
  }