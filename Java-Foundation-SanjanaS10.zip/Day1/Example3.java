class Example3{
   public static void main(String args[]){
    
byte a =9;
short b =23;
int c = 100;
long d =12;     

 float f =8.9f;
  double s =55.77;
  char cc= 'E';
     boolean bb = true;
     String str = "sanjana";
     System.out.println("byte is" +a);
     System.out.println(" short is" +b);
     System.out.println("int is" +c);
      System.out.println("long is" +d); System.out.println("float is" +f); 
     System.out.println("double is" +s);
     System.out.println("char is"+cc);
     System.out.println("boolean is" +bb);
     System.out.println("string is" +str);
   }
}

     