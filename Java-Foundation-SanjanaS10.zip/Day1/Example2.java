class Example2{
 
  public static void main(String args[]){
    int a=7;
    int b=9;
    int c=a+b;
    System.out.println("addition is" +c);
  }
}
    