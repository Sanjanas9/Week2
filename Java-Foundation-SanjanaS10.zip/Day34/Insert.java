import java.util.Scanner;
public class InsertElementToArray{
  public static void main(String args[]){
    scanner scanner new Scanner
  }
}