public class Example1 {
 
    public static void main(String[] args) {
        
        String str="Hi welcome bye";
        System.out.println(str.startsWith("hello Hi"));
        System.out.println(str.endsWith("bye"));
    }
 
}