public class Example1 {
 
    public static void main(String[] args) {
        
        String str=" welcome ";
        
         boolean b=str.contains("come");
         System.out.println(b);
         
         System.out.println(str.contains("hello"));
    }
 
}