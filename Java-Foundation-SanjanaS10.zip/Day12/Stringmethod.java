import.java.util.scanner;
class Stringmethod{
  public static void main(Strings args[]){
    Scanner s =new Scanner(System.in);
    System.out.println("enter your name")
      name=s.nextLine;
    if (name.length()<5 || name.length()>15){
      System.out.println("invalid")
    }
    if()
  }
}