public class Example1 {
 
    public static void main(String[] args) {
        
        String str=" wel come ";
        
        System.out.println(str.length());
 
        str=str.trim();
        System.out.println(str.length());
 
    }
 
}