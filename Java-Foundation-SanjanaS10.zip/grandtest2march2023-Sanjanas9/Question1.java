import java.util.Scanner;
class Question1{
  public static void main (String args[]){
    Scanner s=new Scanner(System.in);
    System.out.println("Enter the amount to withdraw(between 100 and 10000,in multiples of 100):");
    int amount=s.nextInt();
    int num500=0,num200=0,num100=0;
    if (amount<100||amount>10000||amount%100!=0)
      {
      System.out.println("Invalid amount, amount must be multiples of 100 between 100 and 10000");
        System.exit(0);
      }
    if (amount>=500){
      num500=amount/500;
      amount%=500;
    }
    if (amount>=200){
      num200=amount/200;
      amount%=200;
    }
    if (amount>=100){
      num100=amount/100;
    }
    int totalnotes=num500+num200+num100;

    
     System.out.println("Minimum number of notes:");
     System.out.println("500:" +num500);
     System.out.println("200:" +num200);
     System.out.println("100:" +num100);
    System.out.println("total notes:" +totalnotes);
  }
}