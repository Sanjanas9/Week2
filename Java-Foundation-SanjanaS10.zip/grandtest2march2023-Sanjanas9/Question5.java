import java.util.Scanner;
class Question5{
   public static void main(String args[]){
     Scanner s=new Scanner(System.in);
     String str="message";
     String input=s.nextLine();
     int i=0;
     for(i=0;i<input.length();i++){
       if(i%2==0){
         System.out.print(input.charAt(i));
       }
     }
     for(i=0;i<input.length();i++){
       if(i%2!=0){
         System.out.print(input.charAt(i));
       }
     }
   }
}