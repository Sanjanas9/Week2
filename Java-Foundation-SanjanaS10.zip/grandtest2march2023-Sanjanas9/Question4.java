import java.util.Scanner;
class Question4{
  public static void main(String args[]){
    Scanner s=new Scanner(System.in);
    System.out.print("Enter a noun:");
    String noun=s.nextLine();
    System.out.print("Enter the adjective:");
    String adjective=s.nextLine();
    System.out.print("Enter activity:");
    String activity=s.nextLine();
    String story=noun + "was really" +adjective+ "today.We learned how to write" +activity+ "today. I cant wait for tomorrow!";
    System.out.println(story);
  }
}