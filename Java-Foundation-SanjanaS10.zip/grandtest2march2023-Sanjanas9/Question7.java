class question7{
  public static void main(String args[]){
    int count=0,dcount=0;
    StringBuffer str=new StringBuffer("acab");
    for (int i=0;i<str.length();i++){
      for (int j=0;j<str.length();j++){
        if(str.charAt(i) == str.charAt(j)){
          count=count+1;
        }
      }
      if (count==str.length()-(count)){
        dcount++;
        break;
      }
    count=0;
  }
  if(dcount>0){
  System.out.println("yes");
  }
else{
  System.out.println("no");
}
}
}
