import java.util.Scanner;
class Question2{
   public static void main(String args[]){
     Scanner s=new Scanner(System.in);
     int arr[]={1,2,3,4,5,6,7,8,9,10};
     int numele=arr.length-1;
     int temp,i=0;
     
     System.out.println("Enter interations:");
     int value=s.nextInt();
     for(i=0;i<value;i++){
       temp=arr[0];
       for(int j=0;j<numele;j++){
         arr[j]=arr[j+1];
       }
       arr[numele]=temp;
     }
 System.out.println("Array is:");
     for(int k=0;k<arr.length;k++){
       System.out.print(arr[k]+" ");
     }
    
  }
}