public class Example1 {
        
    public static void main(String[] args) {
        
        String firstNumber="10",secondNumber="20";   // string to int
          
          int a=Integer.parseInt(firstNumber);
          int b=Integer.parseInt(secondNumber);
          
          System.out.println(a+b);
          
          
         
    }
 
}