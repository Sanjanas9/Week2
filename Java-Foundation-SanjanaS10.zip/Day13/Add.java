import.java.util.Scanner;
class Add{
  public static void main(String args[]){
    Scanner s=new Scanner(System.in);
    int arr[]={10,90,88,2,44,6,77,3,80};
    System.out.println("Enter the number:");
    int num=s.nextInt();
    int v=0,count=0,i index
  }
}