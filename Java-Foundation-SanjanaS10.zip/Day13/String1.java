public class Example1 {
        
    public static void main(String[] args) {
        
        int a=100,b=20;
        System.out.println(a+b);
        String str1=String.valueOf(a);
        String str2=String.valueOf(b);
        System.out.println(str1+str2);
        
          
         
    }
               
}