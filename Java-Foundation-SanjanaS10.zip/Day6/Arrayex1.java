
    class Example1 
    { public static void main(String args[])
     {
      int arr[]={23,45,12,90,55,33};    System.out.println(arr[2]); 
       System.out.println(arr[5]);     
     }
    }
