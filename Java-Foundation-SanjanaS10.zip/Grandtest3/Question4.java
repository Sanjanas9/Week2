import java.util.Scanner;
class Employee{
  String name;
  String email;
  int id;
  int mobileNo;
  double basicPay;
  String address;

  public Employee(String name,int id,String address,String email,int mobileNo,double basicPay){
    this.name=name;
    this.id=id;
    this.address=address;
    this.email=email;
    this.mobileNo=mobileNo;
    this.basicPay=basicPay;
  }
  public double calculateDA(){
    return 0.97*basicPay;
  }
  public double calculateHRA(){
    return 0.1*basicPay;
  }
  public double calculatePF(){
     return 0.12*basicPay;
}
   public double calculateStaffClubFund(){
     return 0.001*basicPay;
   }
   public double calculateGrossSalary(){
     return basicPay+calculateDA()+ calculateHRA();
   }
   public double calculateNetSalary(){
     return calculateGrossSalary()- calculatePF-calculateStaffClubFund();
   }
  public void printPaySlip(){
    System.out.println("Pay slip for"+name);
    System.out.println("id"+id);
    System.out.println("address"+address);
    System.out.println("Email"+email);
    System.out.println("mobile"+mobileNo);
    System.out.println("basic pay"+basicPay);
    System.out.println("DA"+calculateDA);
    System.out.println("HRF"+calculateHRF);
     System.out.println("PF"+calculatePF());
    System.out.println("Staff club fund"+calculateStaffClubFund());
     System.out.println("GrossSalary"+calculateGrossSalary());
     System.out.println("Net salary"+calculateNetSalary());   
  }
}
class programmer extends Employee{
  public Programmer(String name,int id,String address,int mobileNo,String email,double basicPay){
    super(name,id,address,email,mobileNo,basicPay);
  }
}
class TeamLead extends Employee{
  public TeamLead(String name,int id,String address,int mobileNo,String email,double basicPay){
    super(name,id,address,email,mobileNo,basicPay);
  }
}
class AssitantProjectManager extends Employee{
  public  AssitantProjectManager(String name,int id,String address,int mobileNo,String email,double basicPay){
    super(name,id,address,email,mobileNo,basicPay);
  }
}
class ProjectManager extends Employee{
  public ProjectManager (String name,int id,String address,int mobileNo,String email,double basicPay){
    super(name,id,address,email,mobileNo,basicPay);
  }
}
public class main{
  public static void main(String args[]){
    Scanner scanner=new Scanner(System.in);

    
    System.out.print("Enter name:");
    String name=scanner.nextLine();

    
     System.out.print("Enter ID:");
    int id=scanner.nextInt();
    scanner.nextLine();

     System.out.print("Enter address:");
    String address=scanner.nextLine();


     System.out.print("Enter mobileNo:");
    int mobileNo=scanner.nextInt();

     System.out.print("Enter basicpay:");
    doubel basicPay=scanner.nextdoube();

    Employee employee=new Employee(name,id,address,email,mobileNo,basicPay);

    scanner.close();

    
    
    
  }
}