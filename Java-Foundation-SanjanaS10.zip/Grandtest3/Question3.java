public class Publication {
  private String title;
  private double price;
  private int copies;

  public Publication(String title,double price,int copies){
    this.title=title;
    this.price=price;
    this.copies=copies;
  }
  public String getTitle(){
    return title;
  }
  public double getPrice(){
    return price;
  }
  public int getCopies(){
    return copies;
  }
  public void setCopies(int copies){
    this.copies=copies;
  }
}
public class Book extends Publication{
  private String author;

  public Book(String title,double price,int copies,String author){
    super(title,price,copies);
    this.author=author;
  }
  public String getAuthor(){
    return author;
  }
}
public class Magazine extends Publicaiton{
  private int orderQty;
  private String currentIssue;
  
}
public Magazine(String title,double price,int copies,int orderQty,String CurrentIssue)
  {
  super(title,price,copies);
  this.orderQty=orderQty;
  this.CurrentIssue=CurrentIssue;
}
public int getOrderQty(){
  return orderQty;
}
public String getCurrentIssue(){
  return currentIssue;
}
}
public class main{
  public static void main(String args[]){
    Book Book =new Book("The girl in london",7.77,999,"sanjana");
    Magazine("fashion week",7.99,444,"march 2023");

    int totalOrdered=book.getCopies()+_magazine.getOrderQty();
    double totalSales=(book.getCopies()+book.getPrice())+(magazine.getPrice());
    System.out.println("Total copies ordered:"+totalOrdered);
     System.out.println("Total sales:"+totalSales);
  }
}
  