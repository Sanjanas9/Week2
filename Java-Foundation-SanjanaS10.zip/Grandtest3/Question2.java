import java.util.Scanner;
 class main{
  public static void main(String args[]){
    Scanner input=new Scanner(System.in);
    System.out.println("Enter the size of the array:");
    int size=input.nextInt();
    int[] arr=new int[size];
    System.out.println("Enter the elements");
    for (int i=0; i<size; i++){
      arr[i]=input.nextInt();
      
    }
    int evenCount=0;
    int oddCount=0;
    int primeCount=0;
    int palindromeCount=0;
    for (int i=0;i<size;i++){
      if(arr[i]%2!=0){
        evenCount++;
        
      }
      if(arr[i]%2!=0){
        oddCount++;
      }
      if(isPrime(arr[i])){
        palindromeCount++;
        
      }
    }
      System.out.println("Number of even numbers:"+evenCount);
     System.out.println("Number of odd numbers:"+oddCount);
     System.out.println("Number of prime numbers:"+primeCount);
       System.out.println("Number of palindrome numbers:"+palindromeCount);
    
  }
  public static boolean isPrime(int num){
    if(num<=1){
      return false;
    }
    for(int i=2;i<=Math.sqrt(num);i++){
      if(num%i==0){
        return false;
      }
    }
    return true;
  }
  public static boolean isPalindrome(int num)
  {
    int reversedNum=0;
    int OriginalNum=num;
    while(num!=0){
      int remainder=num%10;
      reversedNum=reversedNum*10+remainder;
      num/=10;
      
    }
    return OriginalNum==reversedNum;
  }
  
}