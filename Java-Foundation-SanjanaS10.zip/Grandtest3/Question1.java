import java.util.Scanner;
class Student{
  private int studentId;
  private String studentName;
  private int rollNo;
  private int marks;
  private int mobileNumber;
  private String address;
  
  public Student(int studentId,String studentName,int rollNo, int mobileNumber,String address,int marks){
    this.studentId=studentId;
    this.studentName=studentName;
    this.rollNo=rollNo;
    this.mobileNumber=mobileNumber;
    this.marks=marks;
    this.address=address;
  }
  public int getStudentId(){
    return studentId;
  }
  public String getStudentName(){
  return studentName;
  }
  

}