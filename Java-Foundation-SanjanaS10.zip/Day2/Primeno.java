import java.util.Scanner;
class Primeno {
  public static void main(String args[]) {
    Scanner s = new Scanner(System.in);
 
    int num=s.nextInt();
    int sum=0,count=0;
    
    for (int k = 1; k <= 100; k++) 
      count = 0;
     for(int i=1;i<=num/2;i++){
       if(num%i==0){
         sum=sum+i;
       }
     }
       if (count == 1) 
        System.out.println(k);
    if(sum==num)
    

}
}

