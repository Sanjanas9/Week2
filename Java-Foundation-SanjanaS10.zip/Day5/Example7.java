class Example7
  {   
    int i;  float b;  double d;  char c;  boolean e;
    public void m1()
                 {   
                   System.out.println("int value: " + i);   
                  System.out.println("float value: " + b);
                  System.out.println("double value: " + d);   
                  System.out.println("char value: " + c);
                  System.out.println("boolean value: " + e);   
                 } 
                 public static void main(String args[])
                 {  
                   Example11 obj = new Example11();  
                   obj.m1();  
                 }
                }
