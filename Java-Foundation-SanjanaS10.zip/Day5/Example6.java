int i = 10;   
int j = 20;   
int a = ++j + i++;  
System.out.println(a);