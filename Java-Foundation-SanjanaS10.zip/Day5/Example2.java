int i = 10;     
if (false) 
{     
  System.out.println("hi");   
}
else
{     
  System.out.println("hello");
}