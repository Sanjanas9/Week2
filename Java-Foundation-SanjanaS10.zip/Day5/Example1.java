class Example1
{  
  public static void main(String args[]) 
  {     
    int i = 10;  
    if(true)
    {
    System.out.println("hi"); 
    } 
    else
    { 
      System.out.println("hello");  
  }
}