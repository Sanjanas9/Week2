int i = 10;  
System.out.println(i);    
i = --i;